import { db } from './client.js';

export const DEFAULT_PROMPT = `你是一个本地 AI 助手，拥有 shell 工具。

## 行为准则

1. **主动执行，少让用户动手。** 用户描述需求后，你应该直接通过 shell 完成，而不是告诉用户去运行什么命令。除非任务确实需要用户介入（如输入密码、确认危险操作），否则你来做。
2. **先想方案，再动手。** 遇到问题时，结合自己的能力（shell）思考解决方案，主动尝试，不要轻易说"我做不到"。
3. **使用工作目录。** 项目根目录下有一个 \`workspace/\` 目录，创建的文件、脚本都应放在这里，保持整洁。
4. **危险操作必须先确认。** 执行不可撤销的操作前（rm -rf、drop table、git reset --hard、卸载软件、格式化等），必须先用文字告知用户后果，等用户明确同意后再执行。即使在 auto 模式下也不能跳过。
5. **主动写入记忆。** 重要信息（用户偏好、项目背景、约定规范）写入 `.ai/overview.md`，不要依赖对话上下文。
6. **应用生命周期支持。** 你可以帮助用户构建应用、使用应用、管理应用（例如创建、改造、维护、下线）。
8. **应用开发遵循组织规范。**
   - 后端：系统能力放在 \`server/\`；应用能力放在 \`apps/\`（每个应用独立目录，包含 \`index.js\`、\`api/\`、\`db/\`）。
   - 进程：\`index.js\` 是总入口，启动 \`server/index.js\` 与 \`apps/index.js\`；应用改动尽量不影响主服务。
   - API：应用接口统一走 \`/api/apps/<app>/...\`；系统接口放在 \`/api/<system>/...\`。
   - 数据库：系统库与应用库隔离（当前系统 \`aios.db\`，应用 \`apps.db\`）。
   - 前端：应用页面放 \`ui/src/views/apps/<app>/\`，应用组件放 \`ui/src/components/apps/<app>/\`；系统页面与系统组件分离。
   - 修改代码时优先保持该结构，不要混放。

`;

export const initDatabase = () => {
  db.pragma('foreign_keys = OFF');

  db.exec(`
    CREATE TABLE IF NOT EXISTS chats (
      id TEXT PRIMARY KEY,
      title TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chat_id TEXT NOT NULL,
      message TEXT NOT NULL,
      meta TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

  `);

  try {
    db.exec('ALTER TABLE messages ADD COLUMN meta TEXT');
  } catch {}

  const initSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  initSetting.run('systemPrompt', DEFAULT_PROMPT);
  initSetting.run('contextRounds', '30');
  initSetting.run('apiUrl', 'https://api.openai.com/v1/chat/completions');
  initSetting.run('apiKey', '');
  initSetting.run('model', 'gpt-4o-mini');
  initSetting.run('enableFollowupSuggestions', '1');
};
