import { readFileSync } from 'fs';
import { join } from 'path';

const getOverview = () => {
  try {
    return readFileSync(join(process.cwd(), '.ai/overview.md'), 'utf8').trim();
  } catch {
    return null;
  }
};

export const buildSystemPrompt = (
  userPrompt,
  appsCatalog = [],
  { enableFollowupSuggestions = true } = {}
) => {
  const cwd = process.cwd();

  let prompt = userPrompt || '';

  // 注入 .ai/overview.md
  const overview = getOverview();
  if (overview) {
    prompt += `\n\n## 记忆\n${overview}`;
  }

  // 追加环境信息
  prompt += `\n\n## 环境
- 项目根目录：${cwd}
- 工作目录：${cwd}/workspace/
- 系统数据库：${cwd}/aios.db（SQLite，表：chats, messages, settings）
- 应用数据库：${cwd}/apps.db（SQLite，应用表如 notebook_notes）
- 记忆文件：${cwd}/.ai/overview.md`;

  if (Array.isArray(appsCatalog) && appsCatalog.length > 0) {
    const lines = appsCatalog.map((app, i) => {
      const summary = app.summary ? ` - ${app.summary}` : '';
      return `${i + 1}. ${app.id} | ${app.title}${summary}`;
    });
    prompt += `\n\n## 应用目录\n你可以帮助用户构建应用、使用应用、管理应用。\n${lines.join('\n')}`;
  } else {
    prompt += `\n\n## 应用目录\n你可以帮助用户构建应用、使用应用、管理应用。`;
  }

  if (enableFollowupSuggestions) {
    prompt += `\n\n## 后续建议输出
在回答的最后追加一个建议标签，格式必须如下：
<suggestions>
1. 建议一
2. 建议二
3. 建议三
</suggestions>

要求：
- 必须给出 3 条与当前对话相关的后续追问建议。
- 建议应简短、具体、可直接提问。`;
  }

  return prompt;
};
