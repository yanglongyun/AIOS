import 'dotenv/config';
import './server/index.js';
import './apps/index.js';
